package com.springboot.bootTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
