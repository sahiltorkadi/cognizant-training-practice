import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-model-way',
  templateUrl: './form-model-way.component.html',
  styleUrls: ['./form-model-way.component.css']
})
export class FormModelWayComponent implements OnInit {

  name : string;
  category : string;
  cost : number;
  myFormGroup : FormGroup;
  myProductName : FormControl;
  constructor(formBuilder : FormBuilder) { 

    this.myProductName =  new FormControl("", Validators.required);
    this.myFormGroup = formBuilder.group({
        "product_name" : this.myProductName,
        "product_category" : new FormControl("Books", Validators.required),
        "product_cost" : new FormControl("500", Validators.compose([Validators.required, this.rangeCheck])) // array of validation rules 
    }); 

    
  }

  saveProduct(){
    this.name = this.myProductName.value;
    this.category = this.myFormGroup.controls['product_category'].value;
    this.cost = parseInt(this.myFormGroup.controls['product_cost'].value);


  }


  rangeCheck(txtControl : FormControl){
    if(parseInt(txtControl.value) < 100 ||parseInt(txtControl.value) > 1000)
        return {
                  "range" : true  
              }



  }


  ngOnInit() {
  }


}
