export class media{
    title:string;
    description:string;
    tag:string;
    img:string;
    constructor(title:string,description:string,tag:string,img:string)
    {
    this.title=title;
    this.description=description;
    this.tag=tag;
    this.img=img;
    }
}
